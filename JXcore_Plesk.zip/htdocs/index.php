<?php

pm_Context::init("jxcore-support");

$application = new pm_Application();
$application->run();

