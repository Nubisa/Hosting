<?php

pm_Context::init("jxcore_support");

$application = new pm_Application();
$application->run();

