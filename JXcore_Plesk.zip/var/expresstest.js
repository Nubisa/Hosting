/**
 * Created by nubisa_krzs on 6/25/14.
 */



//var express = require("express");
var express = require("/opt/psa/var/modules/jxcore_support/native_modules/node_modules/express/");


/*

jx_ub32/jx -e 'require("express")'
jx_ub32/jx -e 'require("/opt/psa/var/modules/jxcore_support/native_modules/node_modules/express/")'


*/